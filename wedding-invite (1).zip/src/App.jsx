
import React from 'react';
import WeddingInvite from './WeddingInvite';

function App() {
  return (
    <div className="App">
      <WeddingInvite />
    </div>
  );
}

export default App;
