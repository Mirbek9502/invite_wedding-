
import React, { useEffect, useState } from "react";

export default function WeddingInvite() {
  const weddingDate = new Date("2025-09-06T17:00:00").getTime();
  const [timeLeft, setTimeLeft] = useState({});

  useEffect(() => {
    const interval = setInterval(() => {
      const now = new Date().getTime();
      const distance = weddingDate - now;
      const days = Math.floor(distance / (1000 * 60 * 60 * 24));
      const hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
      const minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
      const seconds = Math.floor((distance % (1000 * 60)) / 1000);
      setTimeLeft({ days, hours, minutes, seconds });
      if (distance < 0) clearInterval(interval);
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="text-center p-8">
      <h2 className="text-5xl mb-2" style={{ fontFamily: 'Leamon Tuesday, cursive' }}>Wedding Day</h2>
      <h1 className="text-4xl font-bold mb-4" style={{ fontFamily: 'Leamon Tuesday, cursive' }}>Мирбек & Ализа</h1>
      <p className="mb-4">06.09.2025 | начало вечера в 17:00</p>
      <p className="mb-4">До свадьбы осталось: {timeLeft.days}д {timeLeft.hours}ч {timeLeft.minutes}м {timeLeft.seconds}с</p>
    </div>
  );
}
